#!/bin/sh
# Script rulare programe
#utserver -settingspath /opt/utorrent-server-alpha-v3_3/
chmod -R 777 /var/www/
#qbittorrent-nox & disown